#Cloth Weaver
#Author: Alexander Kane
#Version: 4.52
#Updated: 2019-3-14
#Copyright © 2019 XANDERAK, LLC

bl_info = {
        "name" : "Cloth Weaver",
        "category": "3D View",
        "author": "XANDERAK, LLC",
        "wiki_url":"https://clothweaver.com/faq/",
        "version":(4, 52),
        "blender": (2, 79, 0),
        "description":"Create 3D Clothing, Fabrics & Accessories!",
        "warning":"Blender 2.8 not fully supported yet..."
        }

import bpy
import atexit
import os
import webbrowser
import base64
import bmesh
from urllib import request
from bpy.types import Panel, Operator, EnumProperty, WindowManager, PropertyGroup

from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       EnumProperty,
                       PointerProperty,
                       )
                    
import bpy.utils.previews


softwaretype = "IndividualPerpetual"
productcode = "pIPyn"
cwcode = "2525"
cKey = ""

offlineerror = "Can't reach license server, check internet & restart Blender"

cVersion = 4.52

bVersion = 2.79

copyright = "Copyright © 2019 XANDERAK, LLC"

errorMSG = "...text alert area..."
corefunctions = 0
editmodefunctions = 0
gpeKio = "cwupdater"
versionstatus = "(You have the latest version!)"
needupdate = "no"
rstatus = "0"
minimarketstatus = "Mini-Market Offline"
downloadPackage = ""
clothobj = "empty"
rigobj = "empty"
characterobj = "empty"
file = bpy.utils.script_path_user()
new = str(file)
new = new.replace("]","")
new = new.replace("[","")
new = new.replace("'","")
bfile = "/addons/cloth.blend"
CWdirectory = "/addons/"
blendfile = new + bfile
CWaddon = new + CWdirectory
rig = "rig"
iconname = ""
images = "/addons/preseticons/"
gallery = new + images
placehold = ""
eqmLop = "ZHcwY3c="
backups = []
preview_collections = {}
useMBL = 0
CWV = 0
softwareCWmain = False
offlinemode = False
lkbegin = "aHR0cHM6Ly9jbG90aHdlYXZlci5jb20vP2VkZF9hY3Rpb249"
lkmid = "YWN0aXZhdGVfbGljZW5zZSZpdGVtX2lkPQ=="
lkend = "JmxpY2Vuc2U9"

def appendClothes(ctype):
    global errorMSG
    print("\n**Importing Clothing**")
    bpy.ops.object.select_all(action='DESELECT')
    print("Clothing Selected = " + ctype)
    
    print("path=" + blendfile)
    
    section   = "\\Object\\"
    object    = ctype

    filepath  = blendfile + section + object
    directory = blendfile + section
    filename  = object

    bpy.ops.wm.append(filepath=filepath, filename=filename, directory=directory)
    #select newly imported object
    bpy.context.scene.objects.active = bpy.context.selected_objects[0]
    imported = bpy.context.object.name
    #ADJUST TO CW SIZER TEMPLATE
    Guides = ['CW-Guide-Shirt','CW-Guide-Pants']
    useGuides = 3
    if bpy.context.scene.tmpShirt is True:
        useGuides = 0
    elif bpy.context.scene.tmpPants is True:
        useGuides = 1
    else:
        useGuides = 3
    
    if useGuides != 3:
        try:
            scales = [0,1,2]
            for i in scales:
                bpy.context.object.location[i] = bpy.data.objects[Guides[useGuides]].location[i]
                bpy.context.object.scale[i] = bpy.data.objects[Guides[useGuides]].scale[i]
            
        except:
            print("general scale")
            errorMSG = "Error: Couldn't align, didn't find 'CW-Sizer-Shirt' object"
    else:
        print("append " + iconname)
 
    return {"FINISHED"}

class QuitsBlender(Operator):
    
    bl_idname = "quitsblender.id"
    bl_label = "quitsblender"
    bl_description = "Quit Blender, you must manually re-open"
    
    def execute(self, context):
        bpy.ops.wm.quit_blender()
        return {"FINISHED"}


def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

lkbegin = base64.b64decode(lkbegin)
lkbegin = str(lkbegin)
lkbegin = lkbegin.split("'")[1]
lkbegin = lkbegin.split("'")[0]

lkmid = base64.b64decode(lkmid)
lkmid = str(lkmid)
lkmid = lkmid.split("'")[1]
lkmid = lkmid.split("'")[0]

lkend = base64.b64decode(lkend)
lkend = str(lkend)
lkend = lkend.split("'")[1]
lkend = lkend.split("'")[0]

#---------------------------LINKS-----------------------------------
class Updates(Operator):
    
    bl_idname = "updates.id"
    bl_label = "updates"
    bl_description = "Download the latest Cloth Weaver!"
    
    def execute(self, context):
        global versionstatus
        import urllib
        import requests
        
        if softwareCWmain is False:
        
            downloadUpdate = "ClothWeaver-" + str(CWV) + "-" + softwaretype + ".zip"
            areas = 'aHR0cHM6Ly9jbG90aHdlYXZlci5jb20vVXBkYXRlci8='
            
            areas = base64.b64decode(areas)
            jp = str(areas)
            jp = jp.split("'")[1]
            jp = jp.split("'")[0]
            
            item = jp + downloadUpdate
            jEpnulra = base64.b64decode(eqmLop)
            
            e = str(jEpnulra)
            e = e.split("'")[1]
            e = e.split("'")[0]
        
            s = requests.get((item), auth=(gpeKio, e))

        else:
            checkVersionURL= lkbegin + "get_version&item_id=" + cwcode + lkend + cKey
            print("cwmainURL: " + checkVersionURL)
            downloadF = ""
            try:
                response = request.urlopen(checkVersionURL)
                result = response.read()
                result = str(result)
                downloadF = result.split('download_link":"')[1]
                downloadF = downloadF.split('"')[0]
                downloadF = downloadF.replace("\\","")
                
            except:
                downloadF = ""
            s = requests.get(downloadF)
        
        downloadfile = CWaddon + "ClothWeaverUpdater.zip"
        
        try:
        
            print("try download file")
            saveit = open(downloadfile, 'wb')
            print("opening file")
            saveit.write(s.content)
            print("writing file")
            saveit.close
            print("Saved to: " + downloadfile)
            try:
                import zipfile
                print("unzipping")
                zip_ref = zipfile.ZipFile(downloadfile, 'r')
                print("extracting")
                zip_ref.extractall(CWaddon)
                zip_ref.close()

                cwZipFile = CWaddon + "ClothWeaver-" + str(CWV) + "-(" + str(bVersion) + ")-" + softwaretype + ".zip"

                print("unzipping Your Blender Version: " + str(bVersion))
                zip_ref = zipfile.ZipFile(cwZipFile, 'r')
                print("extracting")
                zip_ref.extractall(CWaddon)
                zip_ref.close()

                versionstatus = "Downloaded! Please Restart Blender."
                print("Download Success!")
                try:
                    print("update download counter")
                    counterurl = "https://clothweaver.com/extradata/dwcounter.php/"
                    response = request.urlopen(counterurl)
                except:
                    print("can't update count")
            except:
                print("Error unzipping files")
                versionstatus = "ERROR: Cannot unzip files..."          
                
        except urllib.error.HTTPError as err:
            if err.code == 404:
                print("Error 404: Update file not found")
                versionstatus = "Error 404: Update file not found"
        except:
                print("Cannot find update")
                versionstatus = "Cannot find update"
        
        return {"FINISHED"}
    
class EditHelp(Operator):
    
    bl_idname = "edithelp.id"
    bl_label = "edithelp"
    bl_description = "View tutorials for this section"
    
    def execute(self, context):
        
        url = "https://www.youtube.com/watch?v=P0Nfz8NFhqY&t=1194s"
        webbrowser.open_new_tab(url)
        
        return {"FINISHED"}
    


class MarketCW(Operator):
    bl_idname = "marketcw.id"
    bl_label = "marketcw"
    bl_description = "Visit the Cloth Weaver Market"
    
    def execute(self, context):
        url = "https://market.clothweaver.com"
        webbrowser.open_new_tab(url)
        
        return {"FINISHED"}

# -----------------------------RIG---------------------------------------
class Rig(Operator):
    
    bl_idname = "rig.id"
    bl_label = "rig"
    bl_description = "Attach cloth to a rig (first define clothing and armature) **IMPORTANT** Rig & Cloth must be visible when using this button. Blender crashes otherwise. I do not know why."
    
    def execute(self, context):
        print("**Attach to Rig**")
        
        bpy.ops.object.select_all(action='DESELECT')
        
        bpy.data.objects[clothobj].select = True
        print("selected " + clothobj)
        bpy.context.scene.objects.active = bpy.data.objects[rigobj]
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='DESELECT')
        bpy.ops.pose.select_all(action='TOGGLE')

        print("selected " + rigobj)
        
        bpy.ops.object.parent_set(type='ARMATURE_AUTO')
        
        bpy.context.scene.objects.active = bpy.data.objects[clothobj]
        
        bpy.ops.object.modifier_move_up(modifier="Armature")
        bpy.ops.object.modifier_move_up(modifier="Armature")
        bpy.ops.object.modifier_move_up(modifier="Armature")
        bpy.ops.object.modifier_move_up(modifier="Armature")

        return {"FINISHED"}

class defcloth(Operator):
    
    bl_idname = "defcloth.id"
    bl_label = "defcloth"
    bl_description = "Select cloth to be rigged then press this button"
    
    def execute(self, context):
        print("\n**define cloth**")
        
        global clothobj
        
        clothobj = bpy.context.object.name
        print("clothobj = " + clothobj)
    
        return {"FINISHED"}

class defrig(Operator):
    
    bl_idname = "defrig.id"
    bl_label = "defrig"
    bl_description = "Select armature (in object mode) then press this button"
    
    def execute(self, context):
        
        global rigobj
        
        print("\n**Define armature**")
        
        rigobj = bpy.context.object.name
        print("rigobj = " + rigobj)
    
        return {"FINISHED"}
#---------------------CREATE CLOTHES BUTTONS--------------------------
class createcloth(Operator):
    bl_idname = "createcloth.id"
    bl_label = "createcloth"
    bl_description = "Create selected clothing (2D flat plane for sewing)"
    
    def execute(self, context):
        print("\n**Create 2D " + iconname + "**")
      
        appendClothes(iconname)
            
        return {"FINISHED"}
    
class createprebuilt(Operator):
    bl_idname = "createprebuilt.id"
    bl_label = "createprebuilt"
    bl_description = "Create selected clothing (3D pre-built model)"
    
    def execute(self, context):
        global iconname
        iconname = iconname + "-pb"
        print("\n**Create 3D " + iconname + "**")
        
        appendClothes(iconname)
            
        return {"FINISHED"}
    
class createcustomcloth(Operator):
    bl_idname = "createcustomcloth.id"
    bl_label = "createcustomcloth"
    bl_description = "Imports custom clothing"
    
    def execute(self, context):
        customitem = bpy.context.scene.customthumbnails.split(".")[0]
        print("\n**Create " + customitem + "**")
      
        appendCustom(customitem)
            
        return {"FINISHED"}
#-----------------------FIX TOWEL FIBERS----------------------------
class fixtowel(Operator):
    
    bl_idname = "fixtowel.id"
    bl_label = "fixtowel"
    bl_description = "Fix display of towel fibers (use after sewing towel on model)"
    
    def execute(self, context):
        print("**Fix fibers**") 
        
        bpy.ops.object.modifier_move_down(modifier="ParticleSystem 1")
        bpy.ops.object.modifier_move_down(modifier="ParticleSystem 1")
        bpy.ops.object.modifier_move_down(modifier="ParticleSystem 1")
        
        return {"FINISHED"}

#-----------------------------MAIN FUNCTIONS-----------------------------------
class GenerateClothing(Operator):
    bl_idname = "gent.id"
    bl_label = "GenClothing"
    
    def execute(self, context):
        print("**Base Clothing**")
        appendClothes("Base")
    
        return {"FINISHED"}
    
class makeGuideShirt(Operator):
    bl_idname = "guideshirt.id"
    bl_label = "makeGuideShirt"
    
    def execute(self, context):
        print("**Create Guide Shirt**")
        appendClothes("CW-Guide-Shirt")
    
        return {"FINISHED"}
    
class makeGuidePants(Operator):
    bl_idname = "guidepants.id"
    bl_label = "makeGuidePants"
    
    def execute(self, context):
        print("**Create Guide pants**")
        appendClothes("CW-Guide-Pants")
    
        return {"FINISHED"}

class AttachClothing(Operator):
    bl_idname = "attach.id"
    bl_label = "AttachClothing"
    bl_description = "Attach cloth to model"
    global backups
    def execute(self, context):
        print("\n**Put On Clothing**")
        bpy.context.scene.sync_mode = 'NONE'
        print("Get name of current selected model")
        currentname = bpy.context.object.name
        print("Remove current model from backup list")
        
        try:
            backups.remove(currentname)
            print("removed " + currentname)
        except:
            print(currentname + " not in list")
        
        print("Duplicate model")
        bpy.ops.object.duplicate()
        backups.append(bpy.context.object.name)
        print(backups)

        print("Hide Backup model")
        bpy.ops.object.hide_view_set(unselected=False)
        print("Select original model")
        bpy.context.scene.objects.active = bpy.data.objects[currentname]
        
        print("*Fold clothing*")
        bpy.ops.object.modifier_remove(modifier="Cloth")
        bpy.context.scene.frame_current = bpy.context.scene.frame_start
        bpy.ops.object.modifier_add(type='CLOTH')
        bpy.context.object.modifiers["Cloth"].collision_settings.use_self_collision = True
        bpy.context.object.modifiers["Cloth"].settings.use_sewing_springs = True
        bpy.context.object.modifiers["Cloth"].settings.sewing_force_max = bpy.context.scene.sewForces
        bpy.context.scene.use_gravity = False
        bpy.context.object.modifiers["Cloth"].settings.quality = 5
        bpy.context.object.modifiers["Cloth"].settings.mass = bpy.context.scene.massClothCustom
        bpy.context.object.modifiers["Cloth"].settings.structural_stiffness = bpy.context.scene.stiffClothCustom
        bpy.context.object.modifiers["Cloth"].settings.bending_stiffness = bpy.context.scene.bendClothCustom
        bpy.context.object.modifiers["Cloth"].settings.vel_damping = 1
        print("play simulation")
        bpy.ops.screen.animation_play()

        return {'FINISHED'}

def get_bmesh(ob):
    obm = bmesh.new()
    if ob.mode == 'OBJECT':
        obm.from_mesh(ob.data)
    elif ob.mode == 'EDIT':
        obm = bmesh.from_edit_mesh(ob.data)
    return obm

class SewClothing(Operator):
    bl_idname = "sew.id"
    bl_label = "SewClothing"
    bl_description = "Sew cloth & smooth"
    
    def execute(self, context):
        print("\n**Sewing cloth**")
        
        bpy.context.scene.sync_mode = 'NONE'
        bpy.ops.object.shade_smooth()
        bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Mirror")
        bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Cloth")
        bpy.ops.object.modifier_add(type='CLOTH')
        bpy.context.object.modifiers["Cloth"].collision_settings.use_self_collision = True
        bpy.context.object.modifiers["Cloth"].settings.use_pin_cloth = True
        bpy.context.object.modifiers["Cloth"].settings.mass = bpy.context.scene.massClothCustom
        bpy.context.object.modifiers["Cloth"].settings.structural_stiffness = bpy.context.scene.stiffClothCustom
        bpy.context.object.modifiers["Cloth"].settings.bending_stiffness = bpy.context.scene.bendClothCustom
        bpy.context.object.modifiers["Cloth"].settings.vertex_group_mass = "pins"
        bpy.context.scene.use_gravity = True
        bpy.context.scene.frame_current = bpy.context.scene.frame_start
        
        print("BMesh Stuffs")
        
        #NEW
        
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action='DESELECT')
        ob = bpy.context.object

        obm = get_bmesh(ob)
        obm.edges.ensure_lookup_table()
        for i in obm.edges:
            bpy.ops.mesh.select_mode(type='EDGE')
            i.select = len(i.link_faces) == 0
            bmesh.update_edit_mesh(ob.data)

        bpy.ops.mesh.edge_collapse()

        bpy.ops.mesh.select_all(action='DESELECT')
        #end new
        
        print("\nExit Loop edit mode")
        bpy.ops.object.editmode_toggle()
        print("add thickness")
        bpy.ops.object.modifier_add(type='SOLIDIFY')
        bpy.context.object.modifiers["Solidify"].thickness = 0.02

        print("smoothing")
        bpy.ops.object.modifier_add(type='SUBSURF')
        bpy.context.object.modifiers["Subsurf"].levels = 2

        print("play simulation")
        bpy.ops.screen.animation_play()
        
        return {'FINISHED'} 

class FixMix(Operator):
    bl_idname = "fixmix.id"
    bl_label = "AdjustMe"
    bl_description = "Attempt to clean up the clothing model"
    
    def execute(self, context):
        print("\n**FixMix**")
        global characterobj
        if characterobj == "empty":
            print("please define a character")
        else:
            try:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Cloth")
            except:
                print("cloth modifier already applied")
            bpy.context.scene.frame_current = 1
            bpy.ops.object.modifier_add(type='SHRINKWRAP')
            bpy.context.object.modifiers["Shrinkwrap"].use_keep_above_surface = True
            bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
            bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
            bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
            bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
            bpy.context.object.modifiers["Shrinkwrap"].target = bpy.data.objects[characterobj]
            bpy.context.object.modifiers["Shrinkwrap"].offset = 0.25
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.vertices_smooth(factor=0.25)
            bpy.ops.object.editmode_toggle()
            bpy.ops.object.modifier_add(type='CLOTH')
            bpy.context.object.modifiers["Cloth"].collision_settings.use_self_collision = True
            bpy.ops.object.modifier_move_up(modifier="Cloth")
            bpy.ops.object.modifier_move_up(modifier="Cloth")
            bpy.ops.object.modifier_move_up(modifier="Shrinkwrap")
            
            bpy.ops.screen.animation_play()
            
        return {'FINISHED'}

class defcharacter(Operator):
    
    bl_idname = "defchar.id"
    bl_label = "defchar"
    bl_description = "Select your character then press this button."
    
    def execute(self, context):
        print("\n**define character**")
        
        global characterobj
        global errorMSG
        
        characterobj = bpy.context.object.name
        print("characterobj = " + characterobj)
        errorMSG = "Character defined!"
    
        return {"FINISHED"}

class RestorePrevious(Operator):
    bl_idname = "restore.id"
    bl_label = "restoreprevious"
    bl_description = "Restore detached clothing **IMPORTANT** these items will appear in your render unless moved to another layer)"
    
    def execute(self, context):
        print("\n**Restore**")
        global errorMSG
        for item in backups:
            try:
                bpy.ops.object.select_all(action='DESELECT')
                bpy.context.scene.objects.active = bpy.data.objects[item]
                bpy.data.objects[item].hide = False
                errorMSG = "Backups Restored!"
            except:
                print("can't restore backup")
                errorMSG = "Error: Some items not found in backup"
        
        return {'FINISHED'}

class DeleteBackups(Operator):
    bl_idname = "deletebackups.id"
    bl_label = "deletebackups"
    bl_description = "Delete backup clothing models"
    def execute(self, context):
        global backups
        print("\n**Delete Backups**")
        bpy.ops.view3d.layers(nr=0, extend=False)
        print(backups)
        for item in backups:
            try:
                print("item = " + item)
                bpy.ops.object.select_all(action='DESELECT')
                bpy.context.scene.objects.active = bpy.data.objects[item]
                bpy.data.objects[item].hide = False
                bpy.data.objects[item].select = True
                bpy.ops.object.delete()
            except:
                print("can't delete backup")
        backups = []
        bpy.ops.view3d.layers(nr=0, extend=False)
        print(backups)
        
        return {'FINISHED'}

class Reflect(Operator):
    bl_idname = "reflect.id"
    bl_label = "reflect"
    bl_description = "Reflect along the Z-Axis (Reflect Left & Right)"
    
    def execute(self, context):
        print("\n**Reflect**")
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.transform.resize(value=(-1, 1, 1))
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}

class simulation(Operator):
    bl_idname = "sim.id"
    bl_label = "sim"
    bl_description = "Restart/Stop Simulation (A/V-sync will be disabled to speed up simulation)"
    
    def execute(self, context):
        print("\n**Restart/Stop Sim**")
        bpy.ops.screen.frame_jump(end=False)
        bpy.context.scene.sync_mode = 'NONE'
        bpy.ops.screen.animation_play()
        return {'FINISHED'}

class addcollision(Operator):
    bl_idname = "addcol.id"
    bl_label = "addcol"
    bl_description = "Gives the character/object a collision, allowing the cloth to interact."
    
    def execute(self, context):
        print("\n**Add Collision**")
        bpy.ops.object.modifier_add(type='COLLISION')
        if bpy.context.scene.MBL is True:
            bpy.context.object.collision.thickness_outer = 0.005

        return {'FINISHED'}
    
class imvuscaledown(Operator):
    bl_idname = "imvuscaledown.id"
    bl_label = "imvuscaledown"
    bl_description = "First: Select all components of your IMVU character [Everything, rig (in object mode), all body mesh object]. Second: use this button to shrink the IMVU character's scale for cloth editing purposes"
    
    def execute(self, context):
        print("\n**IMVU Scale Down**")
        
        if bpy.context.scene.IMVU is True:
            bpy.ops.transform.resize(value=(0.01, 0.01, 0.01), constraint_axis=(False, False, False), constraint_orientation='LOCAL', mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
            bpy.ops.view3d.snap_cursor_to_center()
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
        return {'FINISHED'}
    
class imvuscaleup(Operator):
    bl_idname = "imvuscaleup.id"
    bl_label = "imvuscaleup"
    bl_description = "First: Select all components of your IMVU character [Everything, rig (in object mode), all body mesh object]. Second: use this button to restore the IMVU character's scale for exporting purposes"
    
    def execute(self, context):
        print("\n**IMVU Scale Up**")
        
        if bpy.context.scene.IMVU is True:
            bpy.ops.transform.resize(value=(100, 100, 100), constraint_axis=(False, False, False), constraint_orientation='LOCAL', mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        return {'FINISHED'}

#---------------------------------MAIN UI PANELS---------------------------
class View3dPanel(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_label = "Cloth Weaver"
    bl_context = "objectmode"
    bl_category = "Cloth Weaver"
    
    #Draw UI
    def draw(self, context):
        layout = self.layout
        #New row
        obj = context.object
        row = layout.row()
        row.label(text=copyright)
        row = layout.row()
        row.label(text= "Running v" + str(cVersion) + " | " + softwaretype)
        row = layout.row()
        row.operator("cwhome.id", text = "www.ClothWeaver.com", icon="INFO")
        row = layout.row()
        updating = row.box()
        updating.label(text="STATUS: " + versionstatus)
        row = layout.row()
        if cKey == "":
            row = layout.row()
            updating.label(text='Please enter your License Key to receive In-App updates')
            row = layout.row()
            scn = context.scene
            updating.prop(scn, 'LK', icon='LOCKED')
            updating.operator("sregister.id", text = "Confirm Key", icon="WORLD")
        
        else:
            if needupdate == "yes":
                if "Downloaded! Please Restart Blender" in versionstatus:
                    updating.operator("quitsblender.id", text = "Quit Blender", icon="QUIT")
                else:
                    updating.operator("updates.id", text = "Download & Update Now", icon="RADIO")
        if rstatus != '0':
            updating.label(text=rstatus, icon="ERROR")
class CoreFunctions(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_label = "Core Functions | Templates | Rigging"
    bl_context = "objectmode"
    bl_category = "Cloth Weaver"
    
    #Draw UI
    def draw(self, context):
        global corefunctions
        global useMBL
        layout = self.layout
        
        #get selected
        obj = context.object
        scn = context.scene
        #Generate Template
        row = layout.row()
        row = layout.row()
        msg = row.box()
        if 'error' in errorMSG:
            msg.label(text=errorMSG, icon="ERROR")
        else:
            msg.label(text=errorMSG, icon="FILE_TICK")
        row = layout.row()
        coref = row.box()
        physicsf = row.box()
        riggingf = row.box()
        if corefunctions == 1:
            coref.alert = False
            physicsf.alert = True
            riggingf.alert = False
        elif corefunctions == 2:
            coref.alert = False
            physicsf.alert = False
            riggingf.alert = True
        else:
            coref.alert = True
            physicsf.alert = False
            riggingf.alert = False
        coref.operator("corefunctions.id", text="Core", icon="SCRIPTWIN")
        physicsf.operator("physicsfunctions.id", text="Templates", icon="MOD_CLOTH")
        riggingf.operator("rigfunctions.id", text="Rigging", icon="POSE_HLT")
        row = layout.row()
        row = layout.row()
        if corefunctions == 1:
            coref.enabled = True
            physicsf.enabled = False
            riggingf.enabled = True
            global iconname
            layout = self.layout
            wm = context.window_manager
            row = layout.row()
            #row = layout.row()
            #row.operator("marketcw.id", text = "Get more items via Cloth Weaver Market", icon="WORLD")
            #row = layout.row()
            #row = layout.row()
            guideshirt = layout.row()
            guidepants = layout.row()
            if bpy.context.scene.tmpShirt is True:
                guidepants.enabled = False
            if bpy.context.scene.tmpPants is True:
                guideshirt.enabled = False
            guideshirt.operator("guideshirt.id", text = "Create Shirt Guide", icon="MOD_CLOTH")
            guideshirt.prop(scn, "tmpShirt")
            row = layout.row()
            guidepants.operator("guidepants.id", text = "Create Pants Guide", icon="MOD_CLOTH")
            guidepants.prop(scn, "tmpPants")
            row = layout.row()
            row.operator("gent.id", text = "Create Base Plane", icon="MESH_PLANE")
            row = layout.row()
            row.label(text="(Click icon below to view all templates)")
            row = layout.row()
            #Presets
            row.template_icon_view(context.scene, "my_thumbnails")
            row = layout.row()
            
            # Just a way to access which one is selected
            iconname = bpy.context.scene.my_thumbnails
            iconname = iconname.split(".")[0]
            col = row.column()
            cols = col.row(True)
            if "Boxer" in bpy.context.scene.my_thumbnails or "GymShorts" in bpy.context.scene.my_thumbnails:
                row.label(text="Derived from the Shorts Template")
                row = layout.row()
                row.operator("createprebuilt.id", text = "3D " + iconname, icon="OBJECT_DATA")
            elif "UnbuttonedShirt" in bpy.context.scene.my_thumbnails:
                row.label(text="Derived from the Collar Shirt Template")
                row = layout.row()
                row.operator("createprebuilt.id", text = "3D " + iconname, icon="OBJECT_DATA")
            elif "Glasses" in bpy.context.scene.my_thumbnails or "Carpet" in bpy.context.scene.my_thumbnails:
                row = layout.row()
                row.operator("createprebuilt.id", text = "3D " + iconname, icon="OBJECT_DATA")
            else:
                cols.operator("createcloth.id", text = "2D " + iconname, icon="MESH_PLANE")
                cols.operator("createprebuilt.id", text = "3D " + iconname, icon="OBJECT_DATA")
                if bpy.context.scene.my_thumbnails == 'Towel.png':
                    row = layout.row()
                    row.operator("fixtowel.id", text = "Fix Towel Fibers", icon="PARTICLES")
                if bpy.context.scene.my_thumbnails == 'CollarShirt.png':
                    row = layout.row()
                    row.label(text="Tip: Re-adjust the collar")
            row = layout.row()
            
            
        elif corefunctions == 2:
            coref.enabled = True
            physicsf.enabled = True
            riggingf.enabled = False
            row = layout.row()
            row.operator("defcloth.id", text = "Define Clothing", icon="MOD_CLOTH")
            row = layout.row()
            row.label(text="Cloth = " + clothobj)
            row = layout.row()
            row.operator("defrig.id", text = "Define Armature", icon="OUTLINER_OB_ARMATURE")
            row = layout.row()
            row.label(text="Armature = " + rigobj)
            row = layout.row()
            row.operator("Rig.id", text = "Attach Cloth to Armature", icon="POSE_HLT")
        else:
            coref.enabled = False
            physicsf.enabled = True
            riggingf.enabled = True
            
            row.label(text="Are you using the following character types?")
            row = layout.row()
            row.prop(scn, "MBL")
            row = layout.row()
            row.prop(scn, "IMVU")
            if bpy.context.scene.IMVU is True:
                row = layout.row()
                row.operator("imvuscaledown.id", text = "Scale character down", icon="MANIPUL")
                row = layout.row()
                row.operator("imvuscaleup.id", text = "Scale character up", icon="MANIPUL")
            row = layout.row()
            row = layout.row()
            row.label(text="1. Select your character's mesh & add collision")
            row = layout.row()
            row.operator("addcol.id", text = "Add Collision to Character", icon="MOD_PHYSICS")
            row = layout.row()
            row = layout.row()
            row.label(text="2. Adjust cloth physics")
            
            layout.prop(scn, 'sewForces', toggle=True)
            layout.prop(scn, 'massClothCustom', toggle=True)
            layout.prop(scn, 'stiffClothCustom', toggle=True)
            layout.prop(scn, 'bendClothCustom', toggle=True)
            row = layout.row()
            row = layout.row()
            row.label(text="3. Fabric")
            row = layout.row()
            col = row.column()
            cols = col.row(True)
            cols.operator("attach.id", text = "1. Put on Clothing", icon="SNAP_SURFACE")
            cols.operator("sew.id", text = "2. Sew Clothing", icon="AUTOMERGE_ON")
            row = layout.row()
            row.label(text="Character = " + characterobj)
            row = layout.row()
            col = row.column()
            column = col.row(True)
            column.operator("defchar.id", text = "3. Define Character", icon="POSE_DATA")
            column.operator("fixmix.id", text = "4. Clean Up", icon="MOD_CLOTH")
            
            #Restore Previous
            row = layout.row()
            row = layout.row()
            row.label(text="Backups")
            row = layout.row()
            column = row.column()
            columns = column.row(True)
            columns.operator("restore.id", text = "Reveal", icon="RECOVER_LAST")
            columns.operator("deletebackups.id", text = "Delete", icon="CANCEL")
            row = layout.row()
            row = layout.row()
            row.label(text="Other")
            row = layout.row()
            row.operator("reflect.id", text = "Reflect", icon="MOD_MIRROR")
            row = layout.row()
            row.operator("sim.id", text = "Restart/Stop Simulation", icon="PLAY")
        row = layout.row()
        row = layout.row()
            
class corefunction(Operator):
    bl_idname = "corefunctions.id"
    bl_label = "corefunctions"
    bl_description = "Display Core Functions"
    def execute(self, context):
        global corefunctions
        corefunctions = 0
        return {'FINISHED'}
    
class physicsfunction(Operator):
    bl_idname = "physicsfunctions.id"
    bl_label = "physicsfunctions"
    bl_description = "Display Physics Functions"
    def execute(self, context):
        global corefunctions
        corefunctions = 1
        return {'FINISHED'}
class rigfunction(Operator):
    bl_idname = "rigfunctions.id"
    bl_label = "rigfunctions"
    bl_description = "Display Rigging Functions"
    def execute(self, context):
        global corefunctions
        corefunctions = 2
        return {'FINISHED'}
    
def generate_previews():
    # We are accessing all of the information that we generated in the register function below
    pcoll = preview_collections["thumbnail_previews"]
    image_location = pcoll.images_location
    
    enum_items = []
            
    fixedgallery = ['Boxers.png','Panties.png','Bra.png','Bikini-Bottom.png','Bikini-Top.png','Swimsuit.png','Towel.png','T-Shirt.png',
    'Shorts.png','GymShorts.png', 'Pants.png','CollarShirt.png', 'UnbuttonedShirt.png','Hoodie.png','Dress.png','Dress-Long.png',
    'Pillow.png','GymBag.png','EyeGlasses.png','SunGlasses.png','CarpetPlane.png']
    
    a = 0
    for i in fixedgallery:
        a = a + 1
        #print(i)
        imagename = i.split(".")[0]
        #print(imagename)
        filepath = image_location + i
        #print(filepath)
        thumb = pcoll.load(filepath, filepath, 'IMAGE')
        enum_items.append((i, i, imagename, thumb.icon_id, a))
    
    return enum_items
            
#------------------------------EDIT MODE OPTIONS------------------------
class polyadd(Operator):
    bl_idname = "polyadd.id"
    bl_label = "polyadd"
    bl_description = "[First select area to add polygons] (Beta Feature: may produce undesireable results) Outline must have same number of vertices for top/bottom and right/left"
    
    def execute(self, context):
        print("\n**Poly Add**")
        #ShowMessageBox("This is a message", "This is a custom title", 'ERROR')
        bpy.ops.mesh.fill_grid()
        bpy.ops.mesh.select_all(action='DESELECT')
        
        return {'FINISHED'}

class backside(Operator):
    bl_idname = "backside.id"
    bl_label = "backside"
    bl_description = "Creates backside of clothing"
    
    def execute(self, context):
        print("\n**Create Backside**")
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.duplicate_move(MESH_OT_duplicate={"mode":1}, TRANSFORM_OT_translate={"value":(0, 1, 0), "constraint_axis":(False, False, False), "constraint_orientation":'GLOBAL', "mirror":False, "proportional":'DISABLED', "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False, "use_accurate":False})
        bpy.ops.mesh.flip_normals()
        bpy.ops.mesh.select_all(action='DESELECT')
        
        return {'FINISHED'}

class joinedge(Operator):
    bl_idname = "joinedge.id"
    bl_label = "joinedge"
    bl_description = "Mark edges for sewing"
    
    def execute(self, context):
        print("\n**Mark edges for sewing**")
        
        bpy.ops.mesh.bridge_edge_loops()
        bpy.ops.mesh.delete(type='ONLY_FACE')
            
        bpy.ops.mesh.select_all(action='DESELECT')
        
        return {'FINISHED'}

class UV(Operator):
    
    bl_idname = "uv.id"
    bl_label = "uv"
    bl_description = "Reset UVs"
    
    def execute(self, context):
        print("\n**Reset UVs**")
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.001)
        bpy.ops.mesh.select_all(action='DESELECT')
        return {"FINISHED"}
    
class markSeam(Operator):
    
    bl_idname = "markseam.id"
    bl_label = "markseam"
    bl_description = "Mark Seam"
    
    def execute(self, context):
        print("\n**Mark Seam**")
        bpy.ops.mesh.mark_seam()
        return {"FINISHED"}

#---------------------------------EDIT MODE PANEL--------------------------------------
class EditModePanel(Panel):

    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_label = "Cloth Weaver"
    bl_context = "mesh_edit"
    bl_category = "Cloth Weaver"
    
    #Draw UI
    def draw(self, context):
        global editmodefunctions
        layout = self.layout
        
        #get selected
        obj = context.object
        scn = context.scene
        #Generate Template
        row = layout.row()
        row.label(text=copyright)
        row = layout.row()
        row = layout.row()
        vertexf = row.box()
        uvf = row.box()
        if editmodefunctions == 1:
            vertexf.alert = False
            uvf.alert = True
        else:
            vertexf.alert = True
            uvf.alert = False
        vertexf.operator("vertexfunctions.id", text="Custom Cloth Edit", icon="EDIT")
        uvf.operator("uvfunctions.id", text="UV Panel", icon="TEXTURE_SHADED")
        row = layout.row()
        row = layout.row()
        
        if editmodefunctions == 1:
            uvf.enabled = False
            vertexf.enabled = True
            row = layout.row()
            row.operator("uv.id", text = "Reset UVs", icon="UV_FACESEL")
            row = layout.row()
            row.operator("markseam.id", text = "Mark Seams", icon="UV_EDGESEL")
        else:
            vertexf.enabled = False
            uvf.enabled = True
            row = layout.row()
            row.operator("EditHelp.id", text="View Tutorial for Custom Clothing", icon="HELP")
            row = layout.row()
            row = layout.row()
            row = layout.row()
            row.label("Step 1: After creating your outline")
            row = layout.row()
            row.operator("polyadd.id", text = "Add Polygons", icon="ROTACTIVE")
            row = layout.row()
            row = layout.row()
            row.label("Step 2: Create a backside")
            row.operator("backside.id", text = "Create Backside", icon="ROTACTIVE")
            row = layout.row()
            
            #help
            row = layout.row()
            row.label("Step 3: Select & define edge groups to be sewn")
            row = layout.row()
            row.label("*Parallel edges")
            row.operator("joinedge.id", text = "Mark Parallel Edge", icon="UV_SYNC_SELECT")
            row = layout.row()
            row.label("Step 4: Exit edit-mode & press 'Put on Clothing'")
            row = layout.row()
            row = layout.row()
            row = layout.row()
            row.label("Vertex Groups")
            ob = context.object
            group = ob.vertex_groups.active

            rows = 2
            if group:
                rows = 3

            row = layout.row()
            row.template_list("MESH_UL_vgroups", "", ob, "vertex_groups", ob.vertex_groups, "active_index", rows=rows)

            col = row.column(align=True)
            col.operator("object.vertex_group_add", icon='ZOOMIN', text="")
            col.operator("object.vertex_group_remove", icon='ZOOMOUT', text="").all = False
            col.menu("MESH_MT_vertex_group_specials", icon='DOWNARROW_HLT', text="")
            if group:
                col.separator()
                col.operator("object.vertex_group_move", icon='TRIA_UP', text="").direction = 'UP'
                col.operator("object.vertex_group_move", icon='TRIA_DOWN', text="").direction = 'DOWN'

            if ob.vertex_groups and (ob.mode == 'EDIT' or (ob.mode == 'WEIGHT_PAINT' and ob.type == 'MESH' and ob.data.use_paint_mask_vertex)):
                row = layout.row()

                sub = row.row(align=True)
                sub.operator("object.vertex_group_assign", text="Assign")
                sub.operator("object.vertex_group_remove_from", text="Remove")

                sub = row.row(align=True)
                sub.operator("object.vertex_group_select", text="Select")
                sub.operator("object.vertex_group_deselect", text="Deselect")
                
            row = layout.row()
           
                
class Vertexfunction(Operator):
    bl_idname = "vertexfunctions.id"
    bl_label = "vertexfunctions"
    bl_description = "Display Cloth Editing Functions"
    def execute(self, context):
        global editmodefunctions
        editmodefunctions = 0
        return {'FINISHED'}      
    
class UVfunction(Operator):
    bl_idname = "uvfunctions.id"
    bl_label = "uvfunctions"
    bl_description = "Display UV Functions"
    def execute(self, context):
        global editmodefunctions
        editmodefunctions = 1
        return {'FINISHED'}      

#------------------------------Startup Functions---------------------------------------
def loadmainprogram():
    global CWV
    print("\n*Load main program*")
    bpy.utils.register_module(__name__)
    print("registered modules")
    
    #CHECK CURRENT SOFTWARE VERSION
    global cVersion
    global versionstatus
    global needupdate
    global minimarketstatus
    
    try:
        urlv = request.urlopen('https://clothweaver.com/extradata/CWv.txt').read()
        minimarketstatus = "Mini-Market Open"
        CWV = str(urlv)
        CWV = CWV.split("'")[1]
        CWV = CWV.split("'")[0]
        if '\\' in CWV:
            CWV = CWV.split('\\')[0]
        print("Latest version: " + CWV)
        print("My version: " + str(cVersion))
        if cVersion < float(CWV):
            versionstatus = "(v" + CWV + " available!)"
            needupdate = "yes"
    except:
        print("\nnot online")
        versionstatus = "(Can't check for updates, not online)"
    
    if minimarketstatus == "Mini-Market Offline":
        print("Mini-Market Offline")
        
    else:
        pass
    
    print("\n**************************************\n* Done Loading...Cloth Weaver Ready! *\n**************************************\n\n")
    
def saveuserpresets(file):
    directory = CWaddon + "customdir.txt"
    print("\n*Saving User Presets*\ndirectory: " + directory + "\ndata: " + file)
    saveFile = open(directory,"w")
    saveFile.write(file)
    saveFile.close

class sregisters(Operator):
    
    bl_idname = "sregister.id"
    bl_label = "sregister"
    bl_description = "Register Key"
    
    def execute(self, context):
        
        global rstatus
        import urllib
        global softwareCWmain
        global cKey
        
        print("\n*Register Key")
        
        if '-' in bpy.context.scene.LK:
            softwareCWmain = False
            print("Gumroad Key")
            urlcw = "https://clothweaver.com/LK-Store/checkLKforward.php/"
            full_url = urlcw + '?LK=' + bpy.context.scene.LK + '&PK=' + productcode
            
            print("checking for license key...")
            try:
                print("connecting to server...")
                response = request.urlopen(full_url)
                result = response.read()
                result = str(result)
                print(result)
                if 'success":true' in result:
                    rstatus = "0"
                    print("License Key is valid")
                    saveKey()
                    try:
                        checkVersion = lkbegin + lkmid + cwcode + lkend + cKey
                        print(checkVersion)
                        response = request.urlopen(checkVersion)
                        print("main key activated")
                    except:
                        print("can't activate main key")
                else:
                    rstatus = "License Key is not valid"
                    print("License Key is not valid")
                    
                    
            except urllib.error.HTTPError as err:
                if err.code == 404:
                    print(offlineerror)
                    rstatus = offlineerror
                else:
                    rstatus = offlineerror
                    print(offlineerror)
                    raise
            except:
                if "license does not exist" in result:
                    rstatus = "License Key not found"
                    print("License Key not found")
                else:   
                    rstatus = offlineerror
                    print(offlineerror)

        else:
            print("CW Main Key")
            softwareCWmain = True
            checkVersionURL = lkbegin + "check_license&item_id=" + cwcode + lkend + bpy.context.scene.LK

            
            try:
                print("contacting server...")
                response = request.urlopen(checkVersionURL)
                result = response.read()
                result = str(result)
                print(result)
                if 'success":true' in result:
                    rstatus = "0"
                    print("License Key is valid")
                    saveKey()
                else:
                    rstatus = "License Key is not valid"
                    print("License Key is not valid")
             
            except urllib.error.HTTPError as err:
                if err.code == 404:
                    print("404 can't reach server...")
                    rstatus = "404 can't reach server..."
                else:
                    rstatus = offlineerror
                    print(offlineerror)
            except:
                    rstatus = offlineerror
                    print(offlineerror)
        
        return {"FINISHED"}
def saveKey():
    global rstatus
    global softwareCWmain
    global cKey
    print("saving key to file")
    try:
                   
        cKey = bpy.context.scene.LK
                    
        print("Saving Key to file")
        saveKeyFile = open(CWaddon + "LKstore.txt","w")
        saveKeyFile.write(cKey)
        saveKeyFile.close
                      
    except:
        print("Can't save key to file")


def register():
    
    print("\n\n**********************\n* Start Cloth Weaver *\n**********************\nCopyright © 2019 XANDERAK, LLC\n\n")
    from bpy.types import Scene
    from bpy.props import StringProperty, EnumProperty
    
    bpy.types.Scene.sewForces = FloatProperty(
        name = "Sewing Force",
        description = "Force when putting on clothing (Higher = stronger)",
        default = 2.00,
        min=0.01
        )
    bpy.types.Scene.massClothCustom = FloatProperty(
        name = "Mass",
        description = "Mass of Cloth",
        default = 0.3,
        min=0.01
        )
    bpy.types.Scene.stiffClothCustom = FloatProperty(
        name = "Stiffness",
        description = "Stiffness of Cloth",
        default = 5,
        min=0.01
        )
    bpy.types.Scene.bendClothCustom = FloatProperty(
        name = "Bending",
        description = "Bending/wrinkles (lower = many small wrinkles | higher = few bigger wrinkles, )",
        default = 0.1,
        min=0.01
        )
    bpy.types.Scene.LK = bpy.props.StringProperty(
        name = "Key",
        description = "Paste License Key"
        )
    bpy.types.Scene.EmailAddress = bpy.props.StringProperty(
        name = "Email",
        description = "Enter email address used for purchase"
        )
    bpy.types.Scene.MBL = BoolProperty(
        name="use Avastar | Manuel Bastioni Lab",
        description="Checkmark if using Avastar or Manuel Bastioni LAB characters",
        default = False
        )
    bpy.types.Scene.IMVU = BoolProperty(
        name="use IMVU",
        description="Checkmark if using IMVU characters",
        default = False
        )
    bpy.types.Scene.tmpShirt = BoolProperty(
        name="use Shirt Guide",
        description="Checkmark if you want the templates to auto scale to the guides",
        default = False
        )
    bpy.types.Scene.tmpPants = BoolProperty(
        name="use Pants Guide",
        description="Checkmark if you want the templates to auto scale to the guides",
        default = False
        )

    # Create a new preview collection (only upon register)
    pcoll = bpy.utils.previews.new()
    
    pcoll.images_location = gallery
    
    # Enable access to our preview collection outside of this function
    preview_collections["thumbnail_previews"] = pcoll
    
    # This is an EnumProperty to hold all of the images
    bpy.types.Scene.my_thumbnails = EnumProperty(
        items=generate_previews(),
        )
        
    global cKey
    global softwareCWmain
    
    keyfile = CWaddon + "LKstore.txt"         

    if os.path.isfile(keyfile):
        currentKey = open(keyfile,"r")
        cKey = str(currentKey.readline().strip())
        print("Check Key from File: '" + cKey + "'")
           
        if '-' in cKey:
            print("Gumroad Key")
            softwareCWmain = False
        else:
            print("CWmain Key")
            softwareCWmain = True
            try:
                checkVersion = lkbegin + lkmid + cwcode + lkend + cKey
                print(checkVersion)
                response = request.urlopen(checkVersion)
                print("main key activated")
            except:
                print("can't activate main key")
                
    else:
        pass
            
    loadmainprogram()


class CWhome(Operator):
    
    bl_idname = "cwhome.id"
    bl_label = "cwhome"
    bl_description = "Visit ClothWeaver.com"
    
    def execute(self, context):
        
        url = "https://clothweaver.com"
        webbrowser.open_new_tab(url)
        
        return {"FINISHED"}
    
def unregister():
    
    print("unregistered")
    blenderexit()
    bpy.utils.unregister_module(__name__)
    from bpy.types import WindowManager
    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()
    
    del bpy.types.Scene.my_thumbnails

if __name__ == "__main__":
    register()

#end
